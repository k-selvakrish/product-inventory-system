from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, g
import mysql.connector
from datetime import date

app = Flask(__name__)
app.secret_key = "selva_secret_key"

# ===================== DATABASE CONNECTION FUNCTION =====================
def get_db_connection():
    if 'db' not in g:
        g.db = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="super_project",
            buffered=True
        )
    return g.db

@app.teardown_appcontext
def close_db_connection(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()

# ===================== INDEX PAGE =====================
@app.route('/')
def index():
    return render_template('index.html')

# ===================== LOGIN =====================
@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('user')
    password = request.form.get('pass')

    db = get_db_connection()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM admin WHERE username=%s AND password=%s", (username, password))
    user = cur.fetchone()
    cur.close()

    if user:
        session['user'] = user['username']
        flash("Login Successful!", "success")
        return redirect(url_for('dashboard'))
    else:
        flash("Invalid Username or Password!", "danger")
        return redirect(url_for('index'))

# ===================== DASHBOARD =====================
@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))
    return render_template('dashboard.html')

# ===================== SUMMARY API =====================
@app.route('/api/summary')
def summary():
    db = get_db_connection()
    cur = db.cursor(dictionary=True)

    cur.execute("SELECT COUNT(*) AS total_customers FROM customers")
    total_customers = cur.fetchone()['total_customers']

    cur.execute("SELECT COUNT(*) AS total_suppliers FROM suppliers")
    total_suppliers = cur.fetchone()['total_suppliers']

    cur.execute("SELECT COUNT(*) AS total_categories FROM categories")
    total_categories = cur.fetchone()['total_categories']

    cur.execute("SELECT COUNT(*) AS total_products FROM products")
    total_products = cur.fetchone()['total_products']

    cur.execute("SELECT SUM(amount) AS today_sales FROM sales WHERE date=%s", (date.today(),))
    today_sales = cur.fetchone()['today_sales'] or 0

    cur.execute("SELECT SUM(amount) AS today_expenses FROM expenses WHERE date=%s", (date.today(),))
    today_expenses = cur.fetchone()['today_expenses'] or 0

    cur.execute("SELECT SUM(profit) AS this_week_profit FROM profit WHERE WEEK(date)=WEEK(CURDATE())")
    week_profit = cur.fetchone()['this_week_profit'] or 0

    cur.execute("SELECT SUM(profit) AS this_month_profit FROM profit WHERE MONTH(date)=MONTH(CURDATE())")
    month_profit = cur.fetchone()['this_month_profit'] or 0

    cur.close()

    return jsonify({
        "total_customers": total_customers,
        "total_suppliers": total_suppliers,
        "total_categories": total_categories,
        "total_products": total_products,
        "today_sales": today_sales,
        "today_expenses": today_expenses,
        "this_week_profit": week_profit,
        "this_month_profit": month_profit
    })

# ===================== CUSTOMER PAGES =====================


# ===================== CUSTOMER LIST =====================
@app.route('/customer')
def customer():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))

    db = get_db_connection()
    cur = db.cursor(dictionary=True)
    cur.execute("SELECT * FROM customers")
    customers = cur.fetchall()
    cur.close()

    return render_template('customer.html', customers=customers)


# ===================== ADD CUSTOMER =====================
@app.route('/cusform', methods=['POST'])
def cusform():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))

    # Fetch form data
    name = request.form.get('name')
    father_name = request.form.get('father_name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    whatsapp = request.form.get('whatsapp')
    address = request.form.get('address')
    state = request.form.get('state')
    pincode = request.form.get('pincode')

    db = get_db_connection()
    cur = db.cursor()
    cur.execute("""
        INSERT INTO customers (name, father_name, email, phone, whatsapp, address, state, pincode)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """, (name, father_name, email, phone, whatsapp, address, state, pincode))
    db.commit()
    cur.close()

    flash("Customer added successfully!", "success")
    return redirect(url_for('customer'))


# ===================== EDIT CUSTOMER =====================
@app.route('/edit_customer/<int:id>', methods=['GET', 'POST'])
def edit_customer(id):
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))

    db = get_db_connection()
    cur = db.cursor(dictionary=True)

    if request.method == 'POST':
        # form data fetch
        name = request.form.get('name')
        father_name = request.form.get('father_name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        whatsapp = request.form.get('whatsapp')
        address = request.form.get('address')
        state = request.form.get('state')
        pincode = request.form.get('pincode')

        # update query
        cur.execute("""
            UPDATE customers 
            SET name=%s, father_name=%s, email=%s, phone=%s, whatsapp=%s, address=%s, state=%s, pincode=%s
            WHERE id=%s
        """, (name, father_name, email, phone, whatsapp, address, state, pincode, id))
        db.commit()
        cur.close()

        flash("Customer updated successfully!", "success")
        return redirect(url_for('customer'))

    else:
        # GET request -> fetch customer data
        cur.execute("SELECT * FROM customers WHERE id=%s", (id,))
        customer = cur.fetchone()
        cur.close()
        if customer is None:
            flash("Customer not found!", "danger")
            return redirect(url_for('customer'))

        return render_template('edit_customer.html', customer=customer)
@app.route('/delete_customer/<int:id>', methods=['GET'])
def delete_customer(id):
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))

    db = get_db_connection()
    cur = db.cursor()
    cur.execute("DELETE FROM customers WHERE id=%s", (id,))
    db.commit()
    cur.close()

    flash("Customer deleted successfully!", "success")
    return redirect(url_for('customer'))



# ===================== SUPPLIER PAGES =====================
@app.route('/supplier')
def supplier():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))

    db = get_db_connection()
    cur = db.cursor(dictionary=True)

    # Fetch all suppliers
    cur.execute("SELECT * FROM suppliers")
    supplier_list = cur.fetchall()

    # Fetch all categories
    cur.execute("SELECT * FROM categories")
    categories_list = cur.fetchall()

    cur.close()
    return render_template('supplier.html', supplier=supplier_list, categories=categories_list)

@app.route('/add_supplier', methods=['POST'])
def add_supplier():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))

    contact_type = request.form.get('contactType')
    contact_id = request.form.get('contactId')
    business_name = request.form.get('businessName')
    prefix = request.form.get('prefix')
    first_name = request.form.get('firstName')
    middle_name = request.form.get('middleName')
    last_name = request.form.get('lastName')
    mobile = request.form.get('mobile')
    alt_contact = request.form.get('altContact')
    landline = request.form.get('landline')
    email = request.form.get('email')
    dob = request.form.get('dob')

    db = get_db_connection()
    cur = db.cursor()
    cur.execute("""
        INSERT INTO suppliers (contact_type, contact_id, business_name, prefix, first_name, middle_name, last_name, mobile, alt_contact, landline, email, dob)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """, (contact_type, contact_id, business_name, prefix, first_name, middle_name, last_name, mobile, alt_contact, landline, email, dob))
    db.commit()
    cur.close()

    flash("Supplier added successfully!", "success")
    return redirect(url_for('supplier'))

# ===================== OTHER PAGES =====================
@app.route('/category')
def category():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))
    return render_template('category.html')

@app.route('/purchase')
def purchase():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))
    return render_template('purchase.html')

@app.route('/profit_of_sales')
def profit():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))
    return render_template('profit_of_sales.html')

@app.route('/expenses')
def expenses():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))
    return render_template('expenses.html')

@app.route('/report')
def report():
    if 'user' not in session:
        flash("Please login first!", "warning")
        return redirect(url_for('index'))
    return render_template('report.html')

# ===================== LOGOUT =====================
@app.route('/logout')
def logout():
    session.pop('user', None)
    flash("Logged out successfully!", "info")
    return redirect(url_for('index'))

# ===================== MAIN =====================
if __name__ == '__main__':
    app.run(debug=True)
