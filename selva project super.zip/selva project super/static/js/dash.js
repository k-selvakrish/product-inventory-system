// Example: Simple animation / console log
document.addEventListener("DOMContentLoaded", () => {
    console.log("Dashboard Loaded Successfully!");
    
    // Small animation: change numbers after load
    const boxes = document.querySelectorAll(".custom-box p");
    boxes.forEach((box, i) => {
        box.style.transition = "all 0.6s ease-in-out";
        box.style.transform = "scale(1.2)";
        setTimeout(() => {
            box.style.transform = "scale(1)";
        }, 600 + (i * 100));
    });
});
// static/js/dashboard.js

async function fetchSummary() {
  try {
    const res = await fetch('/api/summary');
    const data = await res.json();

    document.getElementById("totalCustomers").innerText = data.total_customers;
    document.getElementById("totalSuppliers").innerText = data.total_suppliers;
    document.getElementById("totalCategories").innerText = data.total_categories;
    document.getElementById("totalProducts").innerText = data.total_products;

    document.getElementById("todaySales").innerText = "₹" + data.today_sales.toLocaleString();
    document.getElementById("todayExpenses").innerText = "₹" + data.today_expenses.toLocaleString();
    document.getElementById("weekProfit").innerText = "₹" + data.this_week_profit.toLocaleString();
    document.getElementById("monthProfit").innerText = "₹" + data.this_month_profit.toLocaleString();

  } catch (err) {
    console.error("Error fetching dashboard summary:", err);
  }
}

// Run immediately on page load
fetchSummary();

// Auto refresh every 10 seconds
setInterval(fetchSummary, 10000);

